public int findkey(int input1,int input2,int input3){
String ip1=String.valueOf(input1);
String ip2=String.valueOf(input2);
String ip3=String.valueOf(input3);
String[] i1=ip1.split("");
String[] i2=ip2.split("");
String[] i3=ip3.split("");
Arrays.sort(i1);
Arrays.sort(i2);
Arrays.sort(i3);
int large=Input.parseInt(i1[4])+Integer.parseInt(i2[4])+Integer.parseInt(i3[4]);
int small=Input.parseInt(i1[1])+Integer.parseInt(i2[1])+Integer.parseInt(i3[1]);
return large-small;
}